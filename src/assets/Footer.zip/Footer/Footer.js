import React from 'react'
import './footer.css'
import { Container,Row,Col } from 'react-bootstrap'
import {AccessTime,Instagram} from '@mui/icons-material'
import {TextField} from '@mui/material'
import Box from '@mui/material/Box';



export default function Footer() {
  return (
    <div className='footer-back-colour'>
           <Container  className=' footer-aling'>
                <Row>
                    <Col md={4}>
                          <div className='text-footer'>
                          <img
                              className=" logo-img"
                              src={require('../../assets/img/LOGO-1.png')}
                               alt="" />
                                
                                <p className='adderss-text'>
                                Wins Tower, CH Cross Road, Nadakkavu East, Kozhikode - 673006 (Near CVN Kalari)
                                </p>
                                <span className='opening'>
                                   <AccessTime className=''/>
                                     <span className='opening-text'> Mon - Sat:- 9:30 am - 7:00 pm</span>
                                     <br/>
                                     <span className='text-closed'>Sun:- Closed</span>
                                </span>
                          </div>
                    </Col>

                    <Col md={2}>
                          <div className='foter-nav-bar-main'>
                              <h5>Contact Links</h5>
                              <ul className='footer-nav-bar'>
                                 <li className='footer-nav-bar-list' >Home</li>
                                <li className='footer-nav-bar-list'>About</li>
                                <li className='footer-nav-bar-list'>Categories</li>
                                <li className='footer-nav-bar-list'>Contact Us</li>
                              </ul>
                          </div>
                    </Col>

                     <Col md={2}>
                              <div className='footer-main-icons'>
                                
                              <img className=" icon-footer-img" src={require('../../assets/img/whatsapp-icon.png')} alt="" />

                              <img className=" icon-footer-img" src={require('../../assets/img/instagram.png')} alt="" />

                              <img className=" icon-footer-img" src={require('../../assets/img/facebook.png')} alt="" />
                             
                              </div>
                     </Col>

                    <Col md={4}>
                       {/* <div className='footer-form'> */}

                          {/* <Box 
                           component="form"  
                          sx={{  
                            '& > :not(style)': { m: 1, width: '25ch' }, 
                            }}
                             noValidate  
                             autoComplete="off"  >

                          <TextField id="standard-basic" label="Name" variant="standard" />
                          <br />
                          <TextField id="standard-basic" label="Email" variant="standard" />
                          <br />
                          <TextField id="standard-basic" label="Phone" variant="standard" />
                          <Box />
                          </div> */}
<div className='footer-form'>
<Box
      component="form"
      sx={{
        '& > :not(style)': { m: 1, width: '40ch' },
       
      }}

    
      noValidate
      autoComplete="off"
    >
      {/* <TextField id="outlined-basic" label="Outlined" variant="outlined" />
      <TextField id="filled-basic" label="Filled" variant="filled" /> */}
      <TextField className='lable-alaing'  id="standard-basic" label ="Name" variant="standard" />
      <TextField className='lable-alaing'  id="standard-basic" label="Email" variant="standard" />
      <TextField className='lable-alaing' id="standard-basic" label="Phone" variant="standard" />
    </Box>
    </div>            
                    </Col>
                </Row>
           </Container>
    </div>
  )
}
